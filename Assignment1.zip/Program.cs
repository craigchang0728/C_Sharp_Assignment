﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$
{
    class Program
    {
        static void Main(string[] args)
        {
            String firstName;
            String lastName;
            String temp;
            DateTime birthdate;
            String address_one;
            String address_two;
            String city;
            String state;
            int zip ;
            String country;
            String others ;
            String address;

            String p_name = "Richard Lin";
            String lab = "Network And System Lab";
            String tel = "07-5254339";

            String program = "Computer Science Engineering";
            String degree = "Master";
            String head = "Ing-Jer Huang";

            Console.WriteLine("Hello.We'd like to acquire some information from you.");
            Console.WriteLine("Please insert your informations:\n===================");
            Console.Write("First name: ");
            firstName = Console.ReadLine();
            Console.Write("Last name: ");
            lastName = Console.ReadLine();
            Console.Write("Birthdate(MM/dd/yyyy): ");
            temp = Console.ReadLine();
            birthdate = Convert.ToDateTime(temp);
            Console.Write("Address Line one: ");
            address_one = Console.ReadLine();
            Console.Write("Address Line two: ");
            address_two = Console.ReadLine();
            Console.Write("City: ");
            city = Console.ReadLine();
            Console.Write("State: ");
            state = Console.ReadLine();
            Console.Write("zip: ");
            zip = int.Parse(Console.ReadLine());
            Console.Write("Country: ");
            country = Console.ReadLine();
            Console.Write("Others to say: ");
            others = Console.ReadLine();
           

            Console.WriteLine("\nThank you for you cooperation! Here is your basic INFO:\n===================");
            

            birthdate = Convert.ToDateTime(temp);
            Console.WriteLine("Name: {0} {1}",firstName,lastName);
            Console.WriteLine("Birthdate: {0}",birthdate.ToString("D"));
            address = address_one + "," + address_two; 
            Console.WriteLine("Address: {0}\nCity: {1}\nState/Province: {2}\nZip/Postall: {3}\nCountry: {4}",address,city,state,zip,country);

            Console.WriteLine("Others to say: {0}", others);

            Console.WriteLine("=================");
            Console.WriteLine("Professor name: {0}\nLab: {1}\nTEL: {2}", p_name,lab,tel);

            Console.WriteLine("\nProgram name: {0}\nDegrees offered: {1}\nDepartment Head: {2}", program, degree, head);
            Console.WriteLine("\nEnter any key to continue...");
            Console.ReadLine();
        }
    }
}
