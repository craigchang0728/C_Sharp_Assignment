﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $safeprojectname$
{
    class Program
    {
        static void Main(string[] args)
        {
            int row,coloum;
            int row_case,coloum_case;
            int total;
            for (row = 0; row < 8; row++)
            {
               row_case = row %2;
               for(coloum = 0;coloum < 8;coloum++)
               {
                   coloum_case = coloum %2;
                   if((row_case + coloum)%2 == 0)
                       Console.Write("X");
                   else
                       Console.Write("O");
                   
                   if(coloum == 7)
                       Console.WriteLine();
               }//end coloum
            }//end row
        
            Console.ReadLine();
            return;
        }
    }
}
